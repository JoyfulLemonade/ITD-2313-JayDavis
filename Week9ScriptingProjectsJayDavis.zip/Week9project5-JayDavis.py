def sorted(lst):  
  for x in range(len(lst) - 1):     
    if(lst[x] > lst[x + 1]):     
      return False    
  return True
#define main branchy boi
def main():
    ans = input("Enter a string of numbers that look like this [2,5,6,7]: ")
    print(sorted(ans))
    
main()
